export DATABASE_URL="postgres://oapfjuxpjztbdf:f09b63f927cfdb213fd9657fe9ae0b6aa04e36de7dcc6853ffc444cb20cb885a@ec2-54-160-96-70.compute-1.amazonaws.com:5432/d297j70okn2768"
export AUTH0_DOMAIN="dev-vrxrz3h3.us.auth0.com"
export ALGORITHMS=['RS256']
export API_AUDIENCE="https://yourlocalapi.com/aip"
export CLIENT_ID=E2CCJ3PsZlTz2UPsumHaaGbhPfMTzvHP
export APP_URL=https://nicg-capstone.herokuapp.com/
export SECRET_KEY='randomkey'